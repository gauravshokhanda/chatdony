from app.db import get_app_db_connection
from datetime import datetime

async def get_or_create_conversation(uuid1, uuid2):
    conn = get_app_db_connection()
    cursor = conn.cursor()

    # Check for existing conversation between these two UUIDs
    query = """
        SELECT cp1.conversation_id
        FROM conversation_participants cp1
        JOIN conversation_participants cp2 ON cp1.conversation_id = cp2.conversation_id
        JOIN conversations c ON c.conversation_id = cp1.conversation_id
        WHERE cp1.user_id = %s AND cp2.user_id = %s AND c.is_group = 0
        LIMIT 1
    """
    cursor.execute(query, (uuid1, uuid2))
    result = cursor.fetchone()

    if result:
        cursor.close()
        conn.close()
        return result[0]

    # Create new private conversation
    cursor.execute("INSERT INTO conversations (room_name, is_group) VALUES (%s, 0)", (f"chat_{uuid1}_{uuid2}",))
    conversation_id = cursor.lastrowid

    cursor.execute("""
        INSERT INTO conversation_participants (conversation_id, user_id)
        VALUES (%s, %s), (%s, %s)
    """, (conversation_id, uuid1, conversation_id, uuid2))
    conn.commit()

    cursor.close()
    conn.close()
    return conversation_id


def create_message(data):
    conn = get_app_db_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO messages (
            conversation_id, sender_id, receiver_id,
            message, message_type, file_url, file_type,
            status, timestamp, reply_to_message_id, is_deleted
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s, %s)
    """

    values = (
        data["conversation_id"],
        data["sender_id"],
        data["receiver_id"],
        data.get("content", ""),
        data.get("message_type", "message"),
        data.get("file_url"),
        data.get("file_type"),
        data.get("status", "sent"),
        data.get("reply_to_message_id", None),
        data.get("is_deleted", 0)
    )

    cursor.execute(sql, values)
    conn.commit()

    message_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return {"message_id": message_id}


def update_message_status(message_id, status):
    conn = get_app_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE messages SET status = %s WHERE message_id = %s", (status, message_id))
    conn.commit()
    cursor.close()
    conn.close()


def mark_message_seen(message_id):
    conn = get_app_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE messages SET status = 'seen' WHERE message_id = %s", (message_id,))
    conn.commit()
    cursor.close()
    conn.close()


def set_user_online(uuid):
    conn = get_app_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE UserTable SET isActive = 1 WHERE uniqueUDID = %s", (uuid,))
    conn.commit()
    cursor.close()
    conn.close()


def set_user_offline(uuid):
    conn = get_app_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE UserTable SET isActive = 0, lastActiveTime = %s WHERE uniqueUDID = %s",
        (datetime.now(), uuid)
    )
    conn.commit()
    cursor.close()
    conn.close()


def get_user_status(uuid):
    conn = get_app_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT isActive, lastActiveTime FROM UserTable WHERE uniqueUDID = %s", (uuid,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result


def get_undelivered_messages(uuid):
    conn = get_app_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT * FROM messages
        WHERE receiver_id = %s AND status = 'sent'
        ORDER BY timestamp ASC
    """, (uuid,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results


def get_user_name(uuid):
    conn = get_app_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM UserTable WHERE uniqueUDID = %s", (uuid,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0] if result else "User"
