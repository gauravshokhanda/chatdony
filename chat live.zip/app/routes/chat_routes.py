from fastapi import APIRouter, HTTPException, Query
from app.db import get_app_db_connection, get_openfire_db_connection
from datetime import datetime

router = APIRouter()

@router.get("/conversation/byuuid/{uuid}")
def get_chat_partners(uuid: str, page: int = Query(1, ge=1), limit: int = Query(20, ge=1, le=100)):
    openfire_conn = get_openfire_db_connection()
    app_conn = get_app_db_connection()

    of_cursor = openfire_conn.cursor()
    app_cursor = app_conn.cursor(dictionary=True)

    offset = (page - 1) * limit

    query = """
        SELECT fromJID, toJID, MAX(sentDate) as lastDate
        FROM ofMessageArchive
        WHERE fromJID LIKE %s OR toJID LIKE %s
        GROUP BY fromJID, toJID
        ORDER BY lastDate DESC
        LIMIT %s OFFSET %s
    """
    like_pattern = f"%{uuid}%"
    of_cursor.execute(query, (like_pattern, like_pattern, limit, offset))
    message_pairs = of_cursor.fetchall()

    partner_uuids = set()
    for row in message_pairs:
        from_uuid = row[0].split('@')[0]
        to_uuid = row[1].split('@')[0]
        if from_uuid != uuid:
            partner_uuids.add(from_uuid)
        elif to_uuid != uuid:
            partner_uuids.add(to_uuid)

    user_map = {}
    if partner_uuids:
        placeholders = ",".join(["%s"] * len(partner_uuids))
        app_cursor.execute(
            f"""SELECT uniqueUDID, name, email, profilePic, gender, phoneNumber,
                       lastActiveTime, description, isActive
                FROM UserTable
                WHERE uniqueUDID IN ({placeholders})""",
            list(partner_uuids)
        )
        users = app_cursor.fetchall()
        user_map = {u["uniqueUDID"]: u for u in users}

    partners = []
    for uid in partner_uuids:
        user = user_map.get(uid)
        if user:
            partners.append({
                "uniqueUDID": user.get("uniqueUDID"),
                "name": user.get("name"),
                "email": user.get("email"),
                "profilePic": user.get("profilePic"),
                "gender": user.get("gender"),
                "phoneNumber": user.get("phoneNumber"),
                "lastActiveTime": user.get("lastActiveTime"),  # already in ISO format
                "matchId": None,  # <- Static null as matchId doesn't exist in DB
                "description": user.get("description"),
                "isActive": user.get("isActive"),
                "isConnected": False,  # <- Static false as isConnected doesn't exist in DB
            })

    of_cursor.close()
    openfire_conn.close()
    app_cursor.close()
    app_conn.close()

    return {
        "code": 200,
        "success": True,
        "page": page,
        "limit": limit,
        "data": partners
    }


# Get chat history between two UUIDs (Paginated)
@router.get("/conversation/{uuid1}/{uuid2}", tags=["Chat"])
def get_conversation_by_uuid(
    uuid1: str,
    uuid2: str,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100)
):
    openfire_conn = get_openfire_db_connection()
    app_conn = get_app_db_connection()

    of_cursor = openfire_conn.cursor()
    app_cursor = app_conn.cursor(dictionary=True)

    offset = (page - 1) * limit
    domain = "@ubuntu-s-1vcpu-1gb-intel-nyc1-01"
    user1_jid = f"{uuid1}{domain}"
    user2_jid = f"{uuid2}{domain}"

    query = """
        SELECT messageID, fromJID, toJID, body, sentDate
        FROM ofMessageArchive
        WHERE (
            (fromJID = %s AND toJID = %s)
            OR (fromJID = %s AND toJID = %s)
        )
        ORDER BY sentDate ASC
        LIMIT %s OFFSET %s
    """
    of_cursor.execute(query, (user1_jid, user2_jid, user2_jid, user1_jid, limit, offset))
    messages = of_cursor.fetchall()

    formatted = []
    for msg in messages:
        message_id, from_jid, to_jid, body, sent_date = msg
        from_uuid = from_jid.split('@')[0]
        to_uuid = to_jid.split('@')[0]
        dt = datetime.utcfromtimestamp(int(sent_date) / 1000)

        formatted.append({
            "id": str(message_id),
            "sender_id": from_uuid,
            "receiver_id": to_uuid,
            "body": body,
            "replied_to": None,  # or fetch from DB if available
            "time": dt.strftime("%I:%M %p"),
            "day": dt.day,
            "b_deleted": False,  # static since not present in DB
            "status": 1,         # static value, or define if you store read/unread
            "image_name": "",    # static empty string
            "local_image_name": "",  # static empty string
            "date": dt.isoformat() + "Z"
        })

    of_cursor.close()
    openfire_conn.close()
    app_cursor.close()
    app_conn.close()

    return {
        "code": 200,
        "success": True,
        "page": page,
        "limit": limit,
        "messages": formatted
    }