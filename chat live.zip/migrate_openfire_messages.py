# scripts/migrate_openfire_messages.py

import sys
import os
import mysql.connector
from datetime import datetime
from app.db import get_app_db_connection, get_openfire_db_connection

def migrate_messages():
    try:
        # Connect to both databases
        openfire_conn = get_openfire_db_connection()
        app_conn = get_app_db_connection()

        openfire_cursor = openfire_conn.cursor(dictionary=True)
        app_cursor = app_conn.cursor()

        # Step 1: Fetch all messages from Openfire
        openfire_cursor.execute("SELECT * FROM ofMessageArchive")
        messages = openfire_cursor.fetchall()

        if not messages:
            print("⚠️ No messages found in Openfire.")
            return

        # Step 2: Prepare insert query for App DB
        insert_query = """
            INSERT INTO messages (
                conversation_id,
                sender_id,
                receiver_id,
                message,
                timestamp,
                message_type,
                status,
                is_private_message
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        inserted_count = 0

        for msg in messages:
            from_jid = msg.get("fromJID", "")
            to_jid = msg.get("toJID", "")
            body = msg.get("body", "")
            sent_date = msg.get("sentDate", None)

            if not (from_jid and to_jid and sent_date and body):
                continue

            sender_id = from_jid.split("@")[0]
            receiver_id = to_jid.split("@")[0]
            timestamp = datetime.fromtimestamp(sent_date / 1000.0)

            app_cursor.execute(insert_query, (
                None,                   # conversation_id (optional)
                sender_id,
                receiver_id,
                body,
                timestamp,
                "text",                 # message_type defaulted to text
                "sent",                # default status
                1                      # is_private_message = true
            ))
            inserted_count += 1

        app_conn.commit()
        print(f"✅ Migrated {inserted_count} messages from Openfire to App DB.")

    except Exception as e:
        print("❌ Error during migration:", str(e))

    finally:
        if 'openfire_cursor' in locals(): openfire_cursor.close()
        if 'openfire_conn' in locals(): openfire_conn.close()
        if 'app_cursor' in locals(): app_cursor.close()
        if 'app_conn' in locals(): app_conn.close()

if __name__ == "__main__":
    migrate_messages()
